# TacticalDEV Trazabilidad - cambios realizados

Se modificó la aplicación base respetando su arquitectura Kotlin + Jetpack Compose + Room.

## 1. Perfiles de usuario
- Se agregó selección de perfil en el login: Técnico, Vendedor y Transportista.
- El perfil queda asociado a cada visita y aparece en el historial.

## 2. Tipo de activo
- Se agregó el campo Tipo de activo: Vitrina freezer / Conservadora.
- El dato queda persistido en Room y visible en historial.

## 3. Verificación de presencia física
- Se agregó geocerca de 250 metros alrededor del punto de venta.
- Se calcula la distancia entre GPS actual y coordenadas del punto.
- También se controla la precisión del GPS: debe ser <= 100 m.
- Una visita no se puede guardar si la presencia no está verificada.
- Las coordenadas de los puntos son de demostración y deben reemplazarse por las coordenadas reales.

## 4. Evidencia fotográfica
- Se mantiene la cámara existente y la fotografía continúa siendo obligatoria.

## 5. Operación sin conectividad
- La visita se guarda localmente en Room.
- Se incorpora estadoSincronizacion = PENDIENTE para dejar la visita preparada para una futura sincronización con API.
- No se inventó una API porque el enunciado indica que actualmente no existe un sistema centralizado.

## 6. Historial
- Se agregó búsqueda por código de activo o punto de venta.
- Se muestran fecha/hora, perfil, tipo de activo, GPS, precisión, distancia, presencia y estado de sincronización.

## 7. Compatibilidad con datos existentes
- Se creó una migración Room de versión 1 a 2 para conservar registros existentes.

## 8. Recomendación para la siguiente etapa
- Reemplazar las coordenadas de demostración por las coordenadas reales de cada punto de venta.
- Implementar una API central cuando TacticalDEV disponga de ella y sincronizar los registros PENDIENTES.
- Como mejora futura, agregar QR para identificar el activo sin escribir manualmente el código.
