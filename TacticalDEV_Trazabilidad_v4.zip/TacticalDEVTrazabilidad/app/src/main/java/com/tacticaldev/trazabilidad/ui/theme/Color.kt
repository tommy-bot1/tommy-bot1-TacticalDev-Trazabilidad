package com.tacticaldev.trazabilidad.ui.theme

import androidx.compose.ui.graphics.Color

// Paleta verde (tema claro)
val Verde40 = Color(0xFF2E7D32)
val VerdeContenedor40 = Color(0xFFC8E6C9)
val VerdeSobreContenedor40 = Color(0xFF0B3D0F)
val VerdeSecundario40 = Color(0xFF388E3C)

// Paleta verde (tema oscuro)
val Verde80 = Color(0xFF81C784)
val VerdeSobrePrimario80 = Color(0xFF003910)
val VerdeContenedor80 = Color(0xFF1B5E20)
val VerdeSobreContenedor80 = Color(0xFFC8E6C9)
val VerdeSecundario80 = Color(0xFFA5D6A7)
val VerdeContenedorSec80 = Color(0xFF2E5B31)
