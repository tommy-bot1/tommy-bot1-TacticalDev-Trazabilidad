package com.tacticaldev.trazabilidad.ui.pantallas

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.tacticaldev.trazabilidad.ui.viewmodel.VisitaViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaHistorial(viewModel: VisitaViewModel, alVolver:()->Unit) {
    val visitas by viewModel.todasLasVisitas.collectAsState(); var filtro by remember { mutableStateOf("") }
    val filtradas = visitas.filter { filtro.isBlank() || it.codigoActivo.contains(filtro,true) || it.nombreTienda.contains(filtro,true) }
    Scaffold(topBar={TopAppBar(title={Text("Historial de Activos")},navigationIcon={IconButton(onClick=alVolver){Icon(Icons.Default.ArrowBack,"Volver")}})}) { p ->
        Column(Modifier.fillMaxSize().padding(p).padding(16.dp)) {
            OutlinedTextField(value=filtro,onValueChange={filtro=it},label={Text("Buscar por activo o punto de venta")},singleLine=true,modifier=Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            if (filtradas.isEmpty()) Box(Modifier.fillMaxSize(),contentAlignment=androidx.compose.ui.Alignment.Center){Text("No hay registros que coincidan.")}
            else LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp)){items(filtradas){ v ->
                Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){
                    Text("${v.codigoActivo} • ${v.tipoActivo}",style=MaterialTheme.typography.titleMedium); Text(v.nombreTienda); Text("Perfil: ${v.rolOperario}"); Text("Visita: ${v.tipoVisita} • Estado: ${v.estadoEquipo}"); Text("Fecha: ${SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(Date(v.marcaTiempo))}"); Text("Presencia: ${if(v.presenciaVerificada) "VERIFICADA" else "NO VERIFICADA"}"); Text("Distancia: ${v.distanciaPuntoVentaMetros.toInt()} m • Precisión GPS: ${v.precisionGps.toInt()} m"); Text("Sincronización: ${v.estadoSincronizacion}"); Text("Observaciones: ${v.observaciones}")
                    if(v.rutaFoto.isNotEmpty()){Spacer(Modifier.height(8.dp));AsyncImage(model=v.rutaFoto,contentDescription="Evidencia",modifier=Modifier.fillMaxWidth().height(150.dp))}
                }}
            }}
        }
    }
}
