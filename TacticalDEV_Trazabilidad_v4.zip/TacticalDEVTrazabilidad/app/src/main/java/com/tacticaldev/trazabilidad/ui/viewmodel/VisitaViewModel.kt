package com.tacticaldev.trazabilidad.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tacticaldev.trazabilidad.datos.local.BaseDatos
import com.tacticaldev.trazabilidad.datos.local.entidad.Visita
import com.tacticaldev.trazabilidad.datos.repositorio.Repositorio
import com.tacticaldev.trazabilidad.dominio.validacion.Validador
import com.tacticaldev.trazabilidad.utilidades.Gps
import com.tacticaldev.trazabilidad.utilidades.Geocerca
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class VisitaViewModel(aplicacion: Application) : AndroidViewModel(aplicacion) {
    private val repositorio: Repositorio
    private val ayudanteUbicacion: Gps
    private val _estadoFormulario = MutableStateFlow(EstadoFormulario())
    val estadoFormulario: StateFlow<EstadoFormulario> = _estadoFormulario.asStateFlow()
    val todasLasVisitas = MutableStateFlow<List<Visita>>(emptyList())
    val totalVisitas = MutableStateFlow(0)
    val fallasCriticas = MutableStateFlow(0)

    var correoActivo: String = ""
        private set
    var nombreActivo: String = ""
        private set
    var rolActivo: String = "Técnico"
        private set

    fun establecerSesion(correo: String, rol: String) {
        correoActivo = correo
        nombreActivo = correo.substringBefore('@').replaceFirstChar { it.uppercase() }
        rolActivo = rol
    }

    fun cerrarSesion() {
        correoActivo = ""
        nombreActivo = ""
        rolActivo = "Técnico"
        _estadoFormulario.value = EstadoFormulario()
    }

    init {
        val dao = BaseDatos.obtenerBaseDatos(aplicacion).daoVisita()
        repositorio = Repositorio(dao)
        ayudanteUbicacion = Gps(aplicacion)
        viewModelScope.launch { repositorio.todasLasVisitas.collect { todasLasVisitas.value = it } }
        viewModelScope.launch { repositorio.cantidadTotal.collect { totalVisitas.value = it } }
        viewModelScope.launch { repositorio.cantidadFallas.collect { fallasCriticas.value = it } }
    }

    fun alCambiarCodigoActivo(codigo: String) = _estadoFormulario.update {
        val r = Validador.validarCodigoActivo(codigo)
        it.copy(codigoActivo = codigo.uppercase(), errorCodigoActivo = r.mensajeError)
    }
    fun alCambiarNombreTienda(nombre: String) = _estadoFormulario.update {
        it.copy(nombreTienda = nombre, latitud = null, longitud = null, presenciaVerificada = false, distanciaPuntoVentaMetros = null, errorUbicacion = null)
    }
    fun alCambiarObservaciones(obs: String) = _estadoFormulario.update {
        it.copy(observaciones = obs, errorObservaciones = Validador.validarObservaciones(obs).mensajeError)
    }
    fun alSeleccionarTipoActivo(tipo: String) = _estadoFormulario.update { it.copy(tipoActivo = tipo) }
    fun alSeleccionarTipoVisita(tipo: String) = _estadoFormulario.update { it.copy(tipoVisita = tipo) }
    fun alSeleccionarEstadoEquipo(estado: String) = _estadoFormulario.update { it.copy(estadoEquipo = estado) }
    fun alCapturarFoto(uri: String) = _estadoFormulario.update { it.copy(uriFoto = uri, errorFoto = null) }

    fun capturarUbicacion() {
        val tienda = _estadoFormulario.value.nombreTienda
        if (tienda.isBlank()) {
            _estadoFormulario.update { it.copy(errorUbicacion = "Selecciona primero el punto de venta") }
            return
        }
        _estadoFormulario.update { it.copy(cargandoUbicacion = true, errorUbicacion = null, presenciaVerificada = false) }
        ayudanteUbicacion.obtenerUbicacionActual(
            alExito = { ubicacion ->
                val (dentro, distancia) = Geocerca.evaluar(tienda, ubicacion)
                val precision = ubicacion.accuracy
                val mensaje = when {
                    !dentro -> "Presencia no verificada. Distancia al punto: ${distancia?.toInt() ?: 0} m. Radio permitido: ${Geocerca.RADIO_PERMITIDO_METROS.toInt()} m."
                    precision > 100f -> "GPS obtenido, pero la precisión es baja (${precision.toInt()} m). Intenta nuevamente en un lugar despejado."
                    else -> null
                }
                val verificada = dentro && precision <= 100f
                _estadoFormulario.update {
                    it.copy(
                        latitud = ubicacion.latitude,
                        longitud = ubicacion.longitude,
                        precisionGps = precision,
                        distanciaPuntoVentaMetros = distancia,
                        presenciaVerificada = verificada,
                        cargandoUbicacion = false,
                        errorUbicacion = mensaje
                    )
                }
            },
            alError = { error -> _estadoFormulario.update { it.copy(cargandoUbicacion = false, errorUbicacion = error.message ?: "Error al obtener GPS") } }
        )
    }

    fun enviarFormulario(alExito: () -> Unit) {
        val e = _estadoFormulario.value
        val rCodigo = Validador.validarCodigoActivo(e.codigoActivo)
        val rTienda = Validador.validarNombreTienda(e.nombreTienda)
        val rObs = Validador.validarObservaciones(e.observaciones)
        val rFoto = Validador.validarFoto(e.uriFoto)
        val rGeo = Validador.validarUbicacion(e.latitud, e.longitud, e.presenciaVerificada)
        if (listOf(rCodigo, rTienda, rObs, rFoto, rGeo).any { !it.esValido }) {
            _estadoFormulario.update { it.copy(errorCodigoActivo = rCodigo.mensajeError, errorNombreTienda = rTienda.mensajeError, errorObservaciones = rObs.mensajeError, errorFoto = rFoto.mensajeError, errorUbicacion = rGeo.mensajeError) }
            return
        }
        viewModelScope.launch {
            repositorio.guardarVisita(
                Visita(
                    correo = correoActivo,
                    nombreOperario = nombreActivo,
                    rolOperario = rolActivo,
                    codigoActivo = e.codigoActivo,
                    tipoActivo = e.tipoActivo,
                    nombreTienda = e.nombreTienda,
                    tipoVisita = e.tipoVisita,
                    estadoEquipo = e.estadoEquipo,
                    observaciones = e.observaciones,
                    rutaFoto = e.uriFoto!!,
                    latitud = e.latitud!!,
                    longitud = e.longitud!!,
                    precisionGps = e.precisionGps ?: 0f,
                    distanciaPuntoVentaMetros = e.distanciaPuntoVentaMetros ?: 0f,
                    presenciaVerificada = e.presenciaVerificada,
                    estadoSincronizacion = "PENDIENTE"
                )
            )
            _estadoFormulario.update { EstadoFormulario(esGuardadoExitoso = true) }
            alExito()
        }
    }
}
