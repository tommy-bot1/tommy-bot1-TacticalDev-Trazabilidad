package com.tacticaldev.trazabilidad.utilidades

import android.location.Location

object Geocerca {
    const val RADIO_PERMITIDO_METROS = 250f

    // Coordenadas de demostración. Deben reemplazarse por las coordenadas reales de los puntos de venta.
    private val puntos = mapOf(
        "Tienda Central" to Pair(-33.4489, -70.6693),
        "Tienda Mall Plaza Norte" to Pair(-33.3668, -70.6814),
        "Tienda Costanera Center" to Pair(-33.4170, -70.6062),
        "Tienda Marina Arauco" to Pair(-33.0205, -71.5518),
        "Tienda Concepción Centro" to Pair(-36.8269, -73.0498)
    )

    fun coordenadasDe(tienda: String): Pair<Double, Double>? = puntos[tienda]

    fun evaluar(tienda: String, ubicacion: Location): Pair<Boolean, Float?> {
        val punto = coordenadasDe(tienda) ?: return Pair(false, null)
        val destino = Location("punto_venta").apply {
            latitude = punto.first
            longitude = punto.second
        }
        val distancia = ubicacion.distanceTo(destino)
        return Pair(distancia <= RADIO_PERMITIDO_METROS, distancia)
    }
}
