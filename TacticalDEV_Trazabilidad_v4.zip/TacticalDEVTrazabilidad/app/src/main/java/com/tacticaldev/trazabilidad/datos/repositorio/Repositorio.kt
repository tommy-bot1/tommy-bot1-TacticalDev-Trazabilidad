package com.tacticaldev.trazabilidad.datos.repositorio

import com.tacticaldev.trazabilidad.datos.local.dao.VisitaDao
import com.tacticaldev.trazabilidad.datos.local.entidad.Visita
import kotlinx.coroutines.flow.Flow

class Repositorio(private val daoVisita: VisitaDao) {
    val todasLasVisitas: Flow<List<Visita>> = daoVisita.obtenerTodasLasVisitas()
    val cantidadTotal: Flow<Int> = daoVisita.obtenerTotalVisitas()
    val cantidadFallas: Flow<Int> = daoVisita.obtenerTotalFallasCriticas()

    suspend fun guardarVisita(visita: Visita) {
        daoVisita.insertarVisita(visita)
    }
}