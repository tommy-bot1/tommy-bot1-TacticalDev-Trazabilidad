package com.tacticaldev.trazabilidad.ui.navegacion

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.tacticaldev.trazabilidad.ui.pantallas.PantallaLogin
import com.tacticaldev.trazabilidad.ui.pantallas.PantallaFormulario
import com.tacticaldev.trazabilidad.ui.pantallas.PantallaHistorial
import com.tacticaldev.trazabilidad.ui.pantallas.PantallaInicio
import com.tacticaldev.trazabilidad.ui.viewmodel.VisitaViewModel

object Destinos { const val LOGIN="login"; const val INICIO="inicio"; const val FORMULARIO="formulario"; const val HISTORIAL="historial" }

@Composable
fun Navegacion(viewModel: VisitaViewModel = viewModel()) {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = Destinos.LOGIN) {
        composable(Destinos.LOGIN) {
            PantallaLogin(onLoginExitoso = { correo, rol ->
                viewModel.establecerSesion(correo, rol)
                nav.navigate(Destinos.INICIO) { popUpTo(Destinos.LOGIN) { inclusive = true } }
            })
        }
        composable(Destinos.INICIO) {
            PantallaInicio(viewModel, { nav.navigate(Destinos.FORMULARIO) }, { nav.navigate(Destinos.HISTORIAL) }) {
                viewModel.cerrarSesion(); nav.navigate(Destinos.LOGIN) { popUpTo(0) { inclusive = true } }
            }
        }
        composable(Destinos.FORMULARIO) { PantallaFormulario(viewModel) { nav.popBackStack() } }
        composable(Destinos.HISTORIAL) { PantallaHistorial(viewModel) { nav.popBackStack() } }
    }
}
