package com.tacticaldev.trazabilidad.ui.pantallas

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tacticaldev.trazabilidad.ui.viewmodel.VisitaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantallaInicio(viewModel: VisitaViewModel, alNavegarAFormulario:()->Unit, alNavegarAHistorial:()->Unit, alCerrarSesion:()->Unit) {
    val total by viewModel.totalVisitas.collectAsState(); val fallas by viewModel.fallasCriticas.collectAsState()
    Scaffold(topBar={TopAppBar(title={Text("Tactical-Trazabilidad")},actions={IconButton(onClick=alCerrarSesion){Icon(Icons.AutoMirrored.Filled.ExitToApp,"Cerrar sesión")}})}) { p ->
        Column(Modifier.fillMaxSize().padding(p).padding(24.dp),verticalArrangement=Arrangement.spacedBy(16.dp),horizontalAlignment=Alignment.CenterHorizontally) {
            Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primaryContainer)){Column(Modifier.padding(20.dp)){Text("Usuario: ${viewModel.correoActivo}");Text("Perfil: ${viewModel.rolActivo}");Spacer(Modifier.height(8.dp));Text("Visitas registradas: $total");Text("Alertas críticas: $fallas",color=MaterialTheme.colorScheme.error)}}
            Spacer(Modifier.weight(1f)); Button(onClick=alNavegarAFormulario,modifier=Modifier.fillMaxWidth().height(56.dp)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(8.dp));Text("Nueva Visita Técnica")}; OutlinedButton(onClick=alNavegarAHistorial,modifier=Modifier.fillMaxWidth().height(56.dp)){Icon(Icons.Default.History,null);Spacer(Modifier.width(8.dp));Text("Historial de Visitas")}; Spacer(Modifier.weight(1f))
        }
    }
}
