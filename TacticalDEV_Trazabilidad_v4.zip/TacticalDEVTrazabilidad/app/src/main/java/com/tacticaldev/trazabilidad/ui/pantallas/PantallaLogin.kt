package com.tacticaldev.trazabilidad.ui.pantallas

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tacticaldev.trazabilidad.ui.viewmodel.LoginViewModel

@Composable
fun PantallaLogin(onLoginExitoso: (String, String) -> Unit, viewModel: LoginViewModel = viewModel()) {
    val rol = viewModel.rolActual()
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "Tactical-Trazabilidad",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            "Trazabilidad y Verificación de Visitas",
            modifier = Modifier.padding(bottom = 24.dp)
        )
        OutlinedTextField(
            value = viewModel.correo,
            onValueChange = viewModel::onCorreoChanged,
            label = { Text("Correo de acceso") },
            placeholder = { Text("nombre@ventas") },
            leadingIcon = { Icon(Icons.Default.Person, null) },
            isError = viewModel.error != null,
            supportingText = {
                Text(viewModel.error ?: "Dominios: @ventas, @tecnico, @transporte")
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            modifier = Modifier.fillMaxWidth()
        )
        if (rol != null) {
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text(
                    "Perfil detectado: $rol",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = {
                if (viewModel.validar()) {
                    viewModel.rolActual()?.let { r ->
                        onLoginExitoso(viewModel.correo.trim().lowercase(), r)
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) { Text("Ingresar") }
    }
}
