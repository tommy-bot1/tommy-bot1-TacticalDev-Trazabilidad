package com.tacticaldev.trazabilidad.ui.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

private val FORMATO_CORREO = Regex("""^[A-Za-z0-9._%+-]+@[A-Za-z]+(\.[A-Za-z]+)*$""")

/** Devuelve el perfil según el dominio del correo (lo que va después de la @), o null si no se reconoce. */
fun rolDesdeCorreo(correo: String): String? {
    val dominio = correo.trim().substringAfter('@', "").substringBefore('.').lowercase()
    return when (dominio) {
        "ventas", "vendedor" -> "Vendedor"
        "tecnico" -> "Técnico"
        "transporte", "transportista" -> "Transportista"
        else -> null
    }
}

class LoginViewModel : ViewModel() {
    var correo by mutableStateOf("")
        private set
    var error by mutableStateOf<String?>(null)
        private set

    fun onCorreoChanged(nuevo: String) {
        correo = nuevo
        error = null
    }

    /** Perfil detectado con lo escrito hasta ahora (null si aún no es válido). */
    fun rolActual(): String? = rolDesdeCorreo(correo)

    fun validar(): Boolean {
        val c = correo.trim()
        error = when {
            c.isBlank() -> "Ingresa tu correo"
            !FORMATO_CORREO.matches(c) -> "Formato inválido. Ejemplo: tomas@ventas"
            rolDesdeCorreo(c) == null -> "Dominio no reconocido. Usa @ventas, @tecnico o @transporte"
            else -> null
        }
        return error == null
    }
}
